<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form loging</title>
</head>
<body>
    <form action="imputprueba2.php" method="POST">
    <label for="username">USUARIO</label>
    <input type="text" id="username" name="username" require>
    <br><br>
    <label for="password">contraseña</label>
    <input type="password" id="password" name="password" require>
    <br><br>
    <input type="submit" value="Ingresar" name="ingresa">
    <br>
    </form>
    
</body>
</html>